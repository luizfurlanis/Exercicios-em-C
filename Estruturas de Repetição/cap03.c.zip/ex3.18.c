#include <stdio.h>
#include <stdlib.h>

int main (){

    for(int i = 1; i <= 5; i++){
        if(i = 1){
            printf("*\n");
        }
        if(i = 2){
            printf("**\n");
        }
        if(i = 3){
            printf("***\n");
        }
        if(i = 4){
            printf("****\n");
        }
        if(i = 5){
            printf("*****");
        }
    }
}
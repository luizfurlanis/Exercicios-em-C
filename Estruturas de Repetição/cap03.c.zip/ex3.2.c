#include <stdio.h>
#include <stdlib.h>

int main (){

    int i = 0;

    for(int i; i <= 50; i+=2){
        printf("%d ", i);
    }
    return 0;
}
#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("Ola Mundo!");
    return 0;
}